import React, { useMemo, useState } from "react";
import axios from "axios";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  AreaChart,
  Area,
  BarChart,
  Bar,
} from "recharts";

/**
 * InsightMesh AI — Full React App (single file)
 * - Dual input on "Insights": consumer search OR upload CSV (company)
 * - Time window + strictness controls wired to run_pipeline
 * - Scraper, Analyzer, Understand, Forecast sandboxes preserved
 * - Matches the backend contracts you shared (FastAPI /api/*)
 */

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "/api",
  timeout: Number(import.meta.env.VITE_API_TIMEOUT ?? 0), // 0 = no client timeout
});

// ---------------- API helpers ----------------
const runPipelineConsumer = async ({ query, platforms, strictness, timeFrom, timeTo, debug }) => {
  const body = {
    filepath: null,
    platforms,
    mode: "fast",
    query_override: query,
    time_from: timeFrom || null,
    time_to: timeTo || null,
    strictness: strictness || null,
    debug: !!debug,
  };
  const { data } = await api.post("/insightmesh/run_pipeline", body);
  return data?.final_report ?? data;
};

const runPipelineCompany = async ({ filepath, platforms, strictness, timeFrom, timeTo, debug }) => {
  const body = {
    filepath,
    platforms,
    mode: "fast",
    query_override: null,
    time_from: timeFrom || null,
    time_to: timeTo || null,
    strictness: strictness || null,
    debug: !!debug,
  };
  const { data } = await api.post("/insightmesh/run_pipeline", body);
  return data?.final_report ?? data;
};

const analyzeReviews = async (reviews) => {
  const { data } = await api.post("/reviews/analyze", { reviews });
  return data;
};

const uploadCSV = async (url, file) => {
  const fd = new FormData();
  fd.append("file", file);
  const { data } = await api.post(url, fd, { headers: { "Content-Type": "multipart/form-data" } });
  return data;
};

// ---------------- UI atoms ----------------
function Card({ title, children, right, className = "", subtitle }) {
  return (
    <div className={`rounded-2xl border border-zinc-800/80 bg-zinc-900/60 p-6 shadow-sm ${className}`}>
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h3 className="text-base font-semibold text-zinc-100">{title}</h3>
          {subtitle && <p className="mt-0.5 text-xs text-zinc-400">{subtitle}</p>}
        </div>
        {right}
      </div>
      <div className="text-zinc-300 text-sm leading-relaxed">{children}</div>
    </div>
  );
}

function Badge({ children, tone = "zinc" }) {
  const map = {
    zinc: "bg-zinc-800 text-zinc-200 border-zinc-700",
    green: "bg-green-900/30 text-green-200 border-green-800",
    red: "bg-red-900/30 text-red-200 border-red-800",
    amber: "bg-amber-900/30 text-amber-200 border-amber-800",
    blue: "bg-blue-900/30 text-blue-200 border-blue-800",
    indigo: "bg-indigo-900/30 text-indigo-200 border-indigo-800",
  };
  return <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-xs ${map[tone]}`}>{children}</span>;
}

function KPITile({ label, value, hint }) {
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/40 p-4">
      <div className="text-xs text-zinc-400">{label}</div>
      <div className="mt-1 text-2xl font-semibold text-zinc-100">{value ?? "—"}</div>
      {hint && <div className="mt-1 text-xs text-zinc-500">{hint}</div>}
    </div>
  );
}

function Chip({ children }) {
  return <span className="rounded-full border border-zinc-700 bg-zinc-800 px-2 py-0.5 text-xs text-zinc-200">{children}</span>;
}

function ErrorToast({ error, onClose }) {
  if (!error) return null;
  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-sm rounded-xl border border-red-800 bg-red-950/70 px-4 py-3 text-sm text-red-100 shadow-lg">
      <div className="mb-2 font-semibold">Error</div>
      <div className="whitespace-pre-wrap break-words">{String(error)}</div>
      <div className="mt-2 text-right">
        <button className="rounded-md border border-red-800/60 px-2 py-0.5 text-xs hover:bg-red-900/40" onClick={onClose}>
          Dismiss
        </button>
      </div>
    </div>
  );
}

function Tabs({ tabs, value, onChange }) {
  return (
    <div className="mb-3 flex flex-wrap gap-2">
      {tabs.map((t) => (
        <button
          key={t}
          className={`rounded-xl border px-3 py-1.5 text-sm ${value === t ? "border-blue-700 bg-blue-900/30 text-blue-200" : "border-zinc-800 bg-zinc-900 text-zinc-300 hover:bg-zinc-800"}`}
          onClick={() => onChange(t)}
        >
          {t}
        </button>
      ))}
    </div>
  );
}

// ---------------- Shared helpers ----------------
const CATEGORY_COLORS = {
  Praise: "bg-emerald-600 text-white",
  Complaint: "bg-rose-600 text-white",
  Suggestion: "bg-amber-500 text-black",
  Prediction: "bg-indigo-500 text-white",
  Neutral: "bg-slate-400 text-black",
};

const starLabelToNumber = (label) => {
  if (!label) return 3;
  const l = String(label).toLowerCase();
  if (l.startsWith("1")) return 1;
  if (l.startsWith("2")) return 2;
  if (l.startsWith("3")) return 3;
  if (l.startsWith("4")) return 4;
  if (l.startsWith("5")) return 5;
  // fallback for e.g. "POSITIVE" etc.
  return 3;
};

const toneForSentiment = (label) => {
  const n = starLabelToNumber(label);
  if (n >= 4) return "green";
  if (n <= 2) return "red";
  return "amber";
};

// ===================== INSIGHTS (dual input) =====================
function InsightsPanel() {
  // Shared controls
  const [platforms, setPlatforms] = useState({ youtube: true, reddit: true });
  const [strictness, setStrictness] = useState("normal");
  const [timeFrom, setTimeFrom] = useState("");
  const [timeTo, setTimeTo] = useState("");
  const [debug, setDebug] = useState(true);

  // Consumer flow
  const [query, setQuery] = useState("Tesla Model Y");

  // Company flow
  const [csvUploading, setCsvUploading] = useState(false);
  const [uploadedPath, setUploadedPath] = useState("");

  // Output
  const [res, setRes] = useState(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState(null);

  const selectedPlatforms = useMemo(
    () => Object.entries(platforms).filter(([, v]) => v).map(([k]) => k),
    [platforms]
  );

  const runConsumer = async () => {
    setLoading(true); setErr(null);
    try {
      const data = await runPipelineConsumer({
        query,
        platforms: selectedPlatforms,
        strictness,
        timeFrom: timeFrom || null,
        timeTo: timeTo || null,
        debug,
      });
      setRes(data);
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.response?.data?.error || e?.message || String(e);
      setErr(msg);
    } finally {
      setLoading(false);
    }
  };

  const onCSV = async (file) => {
    setCsvUploading(true); setErr(null);
    try {
      const u = await uploadCSV("/understand/upload", file);
      const path = u?.raw_path || u?.rawPath || "";
      setUploadedPath(path);
      if (!path) throw new Error("Upload succeeded but no server path returned.");
      setLoading(true);
      const data = await runPipelineCompany({
        filepath: path,
        platforms: selectedPlatforms,
        strictness,
        timeFrom: timeFrom || null,
        timeTo: timeTo || null,
        debug,
      });
      setRes(data);
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.response?.data?.error || e?.message || String(e);
      setErr(msg);
    } finally {
      setCsvUploading(false); setLoading(false);
    }
  };

  // Derived
  const overview = res?.analysis?.overview;
  const exec = res?.analysis?.executive_summary;
  const actionItems = res?.analysis?.action_items ?? [];
  const starData = useMemo(() => {
    const stars = overview?.stars ?? {};
    return [1,2,3,4,5].map((n) => ({ label: `${n}★`, count: Number(stars[`${n} star`] ?? stars[`${n} stars`] ?? 0) }));
  }, [overview]);

  const perReview = (res?.analysis?.per_review ?? []).map((r) => ({
    ...r,
    category: r.review_category,
    topics: r.topic_labels,
    text: r.original,
  }));

  return (
    <div className="space-y-6">
      {/* Dual input header */}
      <Card title="Insights" subtitle="Run end-to-end using a product query or a CSV dataset" right={<Badge>Pipeline</Badge>}>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-12">
          {/* Consumer search */}
          <div className="md:col-span-7 rounded-xl border border-zinc-800/70 bg-zinc-900/50 p-4">
            <div className="mb-2 text-sm font-medium text-zinc-200">Consumer Search</div>
            <div className="flex flex-col gap-2 md:flex-row md:items-center">
              <input
                className="w-full rounded-xl border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-700"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="e.g., Sony WH-1000XM5"
              />
              <button onClick={runConsumer} disabled={loading} className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50">
                {loading ? "Running…" : "Run"}
              </button>
            </div>
          </div>

          {/* CSV upload */}
          <div className="md:col-span-5 rounded-xl border border-zinc-800/70 bg-zinc-900/50 p-4">
            <div className="mb-2 text-sm font-medium text-zinc-200">Company Dataset (CSV)</div>
            <input type="file" accept=".csv,text/csv" onChange={(e) => e.target.files?.[0] && onCSV(e.target.files[0])} className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-2 py-1 text-sm" />
            {csvUploading && <div className="mt-2 text-xs text-zinc-400">Uploading…</div>}
            {uploadedPath && <div className="mt-1 truncate text-xs text-zinc-500">Saved: {uploadedPath}</div>}
          </div>
        </div>

        {/* Controls row */}
        <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-12">
          <div className="md:col-span-4 flex flex-wrap items-center gap-3">
            {Object.keys(platforms).map((p) => (
              <label key={p} className="flex items-center gap-1 text-xs">
                <input type="checkbox" className="accent-blue-600" checked={platforms[p]} onChange={(e) => setPlatforms((prev) => ({ ...prev, [p]: e.target.checked }))} />
                <span className="capitalize">{p}</span>
              </label>
            ))}
            <label className="flex items-center gap-1 text-xs">
              <input type="checkbox" className="accent-blue-600" checked={debug} onChange={(e) => setDebug(e.target.checked)} /> Debug
            </label>
          </div>
          <div className="md:col-span-8 grid grid-cols-2 gap-2 md:grid-cols-4">
            <select value={strictness} onChange={(e) => setStrictness(e.target.value)} className="rounded-lg border border-zinc-700 bg-zinc-900 px-2 py-1 text-xs">
              <option value="low">strictness: low</option>
              <option value="normal">strictness: normal</option>
              <option value="high">strictness: high</option>
            </select>
            <input type="datetime-local" value={timeFrom} onChange={(e) => setTimeFrom(e.target.value)} className="rounded-lg border border-zinc-700 bg-zinc-900 px-2 py-1 text-xs" placeholder="time_from" />
            <input type="datetime-local" value={timeTo} onChange={(e) => setTimeTo(e.target.value)} className="rounded-lg border border-zinc-700 bg-zinc-900 px-2 py-1 text-xs" placeholder="time_to" />
            <div className="flex items-center text-xs text-zinc-400">Optional time window</div>
          </div>
        </div>
      </Card>

      {/* Summary + KPIs */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-12">
        <Card title="Executive Summary" className="md:col-span-12" subtitle="Highlights from reviews">
          {!res && <div className="text-sm text-zinc-500">Run the pipeline using search or CSV.</div>}
          {res && (
            <ul className="list-disc pl-5 text-sm space-y-1">
              <li>
                Query: <span className="font-medium">{res?.meta?.query_used ?? (uploadedPath ? "(from dataset)" : query)}</span>
                {res?.meta?.elapsed_ms !== undefined && <span className="ml-2 text-zinc-400">({(res.meta.elapsed_ms/1000).toFixed(1)}s)</span>}
              </li>
              {overview && (
                <li>
                  Mood index <span className="font-medium">{typeof overview.mood_index === 'number' ? overview.mood_index.toFixed(2) : '—'}</span>, avg sentiment <span className="font-medium">{overview?.average_sentiment?.toFixed?.(2) ?? '—'}</span>{" "}
                  {starData?.some?.((d) => d.count > 0) && `, stars: ${starData.map((d) => `${d.label} ${d.count}`).join(" · ")}`}
                </li>
              )}
              {exec?.totals_by_category && (
                <li>
                  Category mix: {Object.entries(exec.totals_by_category).map(([k, v], i) => (
                    <span key={k} className="mr-2">{k}: <span className="font-medium">{String(v)}</span>{i < Object.keys(exec.totals_by_category).length - 1 ? "," : ""}</span>
                  ))}
                </li>
              )}
            </ul>
          )}
        </Card>

        {(overview || res) && (
          <Card title="Key Metrics" className="md:col-span-12">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
              <KPITile label="Mood Index" value={typeof overview?.mood_index === 'number' ? overview.mood_index.toFixed(2) : '—'} hint="range −1…+1" />
              <KPITile label="Avg Sentiment" value={overview?.average_sentiment?.toFixed?.(2) ?? '—'} />
              <KPITile label="Total Reviews" value={(res?.analysis?.per_review ?? []).length || '—'} />
              <KPITile label="Strictness" value={strictness} />
            </div>
          </Card>
        )}

        {(overview?.stars || exec?.totals_by_category) && (
          <Card title="Distribution" className="md:col-span-12" subtitle="Star mix & category totals">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-12">
              <div className="md:col-span-7 h-48">
                <ResponsiveContainer>
                  <BarChart data={starData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="label" />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="count" name="Count" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="md:col-span-5 flex flex-wrap items-start gap-2">
                {Object.keys(exec?.totals_by_category || {}).length === 0 && <div className="text-sm text-zinc-500">No category totals.</div>}
                {Object.entries(exec?.totals_by_category || {}).map(([k, v]) => (<Chip key={k}>{k}: {String(v)}</Chip>))}
              </div>
            </div>
          </Card>
        )}

        {!!(exec?.top_reasons_overall) && (
          <Card title="Top Reasons Overall" className="md:col-span-12" subtitle="Most-cited reasons by category">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
              {Object.entries(exec.top_reasons_overall).map(([cat, reasons]) => (
                <div key={cat} className="rounded-xl border border-zinc-800 p-3">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${CATEGORY_COLORS[cat] ?? 'bg-zinc-800 text-zinc-200'}`}>{cat}</span>
                  <ul className="mt-2 ml-4 list-disc text-sm space-y-1">
                    {(reasons || []).slice(0, 5).map((r, i) => (<li key={i}>{String(r)}</li>))}
                  </ul>
                </div>
              ))}
            </div>
          </Card>
        )}

        {!!(exec?.top_aspects?.length) && (
          <Card title="Top Aspects" className="md:col-span-12" subtitle="Themes and reasons drawn from reviews">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              {(exec.top_aspects || []).slice(0, 6).map((a, i) => (
                <div key={i} className="rounded-xl border border-zinc-800 p-4">
                  <div className="mb-1 flex items-center justify-between">
                    <div className="text-sm font-medium text-zinc-100">{a?.aspect ?? 'Aspect'}</div>
                    <Badge tone="amber">{a?.mentions ?? 0} mentions</Badge>
                  </div>
                  {typeof a?.share_of_reviews === 'number' && (
                    <div className="mb-2 text-xs text-zinc-400">{Math.round(a.share_of_reviews * 100)}% of reviews</div>
                  )}
                  <div className="space-y-2">
                    {(a?.by_category ?? []).slice(0, 3).map((bc, j) => (
                      <div key={j}>
                        <div className="text-xs text-zinc-400">{bc?.category ?? 'Category'}</div>
                        <ul className="ml-4 list-disc text-sm">
                          {(bc?.reasons ?? []).slice(0, 2).map((r, k) => (<li key={k}>{String(r)}</li>))}
                        </ul>
                        {(bc?.quotes ?? []).slice(0, 2).map((q, qx) => (
                          <blockquote key={qx} className="mt-1 rounded-lg border border-zinc-800 bg-zinc-900/40 p-2 text-xs italic text-zinc-300">
                            “{q?.quote ?? ''}”
                          </blockquote>
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Per-review */}
        <Card title="Per-review" right={<Badge>table</Badge>} className="md:col-span-12">
          <div className="overflow-auto rounded-xl border border-zinc-800">
            <table className="min-w-full text-left text-sm">
              <thead className="sticky top-0 bg-zinc-900/90 text-zinc-400 backdrop-blur">
                <tr>
                  <th className="px-3 py-2">Sentiment</th>
                  <th className="px-3 py-2">Category</th>
                  <th className="px-3 py-2">Topics</th>
                  <th className="px-3 py-2">Keyphrases</th>
                  <th className="px-3 py-2">Text</th>
                </tr>
              </thead>
              <tbody>
                {perReview.map((r, i) => (
                  <tr key={i} className="border-t border-zinc-800 odd:bg-zinc-900/40">
                    <td className="px-3 py-2">
                      <Badge tone={toneForSentiment(r?.sentiment)}>{r?.sentiment ?? "—"}</Badge>
                    </td>
                    <td className="px-3 py-2">{r?.category ?? "—"}</td>
                    <td className="px-3 py-2">
                      <div className="flex max-w-xs flex-wrap gap-1">
                        {(r?.topics ?? []).map((t, j) => (<Badge key={j}>{String(t)}</Badge>))}
                      </div>
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex max-w-xs flex-wrap gap-1">
                        {(r?.keyphrases ?? []).slice(0, 6).map((k, j) => (<Badge key={j}>{String(k)}</Badge>))}
                      </div>
                    </td>
                    <td className="px-3 py-2 max-w-3xl truncate" title={r?.text}>{r?.text ?? ""}</td>
                  </tr>
                ))}
                {!perReview.length && (
                  <tr>
                    <td className="px-3 py-6 text-center text-zinc-500" colSpan={5}>
                      {res ? "No rows (did filters eliminate everything?)" : "Run the pipeline to populate rows."}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
      <ErrorToast error={err} onClose={() => setErr(null)} />
    </div>
  );
}

// ===================== SCRAPER SANDBOX =====================
function ScraperPanel() {
  // YouTube
  const [ytQuery, setYtQuery] = useState("Tesla Model Y");
  const [ytMaxVideos, setYtMaxVideos] = useState(4);
  const [ytMaxComments, setYtMaxComments] = useState(60);
  const [ytAfter, setYtAfter] = useState("");
  const [ytBefore, setYtBefore] = useState("");
  const [ytStrict, setYtStrict] = useState("normal");
  const [ytRes, setYtRes] = useState(null);
  const [ytLoading, setYtLoading] = useState(false);

  // Reddit
  const [rdtSubs, setRdtSubs] = useState("TeslaMotors, electricvehicles");
  const [rdtQuery, setRdtQuery] = useState("Tesla Model Y");
  const [rdtLimit, setRdtLimit] = useState(80);
  const [rdtTime, setRdtTime] = useState("month");
  const [rdtStrict, setRdtStrict] = useState("normal");
  const [rdtRes, setRdtRes] = useState(null);
  const [rdtLoading, setRdtLoading] = useState(false);
  const [err, setErr] = useState(null);

  const runYT = async () => {
    setYtLoading(true); setErr(null);
    try {
      const { data } = await api.post("/reviews/scrape/youtube", {
        query: ytQuery,
        max_videos: Number(ytMaxVideos),
        max_comments: Number(ytMaxComments),
        published_after: ytAfter || null,
        published_before: ytBefore || null,
        strictness: ytStrict,
      });
      setYtRes(data);
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.response?.data?.error || e?.message || String(e);
      setErr(msg);
    } finally {
      setYtLoading(false);
    }
  };

  const runReddit = async () => {
    setRdtLoading(true); setErr(null);
    try {
      const { data } = await api.post("/reviews/scrape/reddit", {
        subreddits: rdtSubs.split(",").map((s) => s.trim()).filter(Boolean),
        query: rdtQuery,
        limit: Number(rdtLimit),
        time_filter: rdtTime,
        strictness: rdtStrict,
      });
      setRdtRes(data);
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.response?.data?.error || e?.message || String(e);
      setErr(msg);
    } finally {
      setRdtLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
      <Card title="YouTube Scraper" right={<Badge>Sandbox</Badge>}>
        <div className="space-y-2">
          <input className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-2 py-1 text-sm" value={ytQuery} onChange={(e) => setYtQuery(e.target.value)} />
          <div className="grid grid-cols-2 gap-2 text-sm">
            <label className="flex items-center gap-1">
              <span>max_videos</span>
              <input type="number" min={1} max={6} className="w-20 rounded-md border border-zinc-700 bg-zinc-900 px-2 py-1" value={ytMaxVideos} onChange={(e) => setYtMaxVideos(e.target.value)} />
            </label>
            <label className="flex items-center gap-1">
              <span>max_comments</span>
              <input type="number" min={1} max={100} className="w-24 rounded-md border border-zinc-700 bg-zinc-900 px-2 py-1" value={ytMaxComments} onChange={(e) => setYtMaxComments(e.target.value)} />
            </label>
            <label className="flex items-center gap-1">
              <span>after</span>
              <input type="datetime-local" className="w-full rounded-md border border-zinc-700 bg-zinc-900 px-2 py-1" value={ytAfter} onChange={(e) => setYtAfter(e.target.value)} />
            </label>
            <label className="flex items-center gap-1">
              <span>before</span>
              <input type="datetime-local" className="w-full rounded-md border border-zinc-700 bg-zinc-900 px-2 py-1" value={ytBefore} onChange={(e) => setYtBefore(e.target.value)} />
            </label>
            <label className="flex items-center gap-1">
              <span>strictness</span>
              <select value={ytStrict} onChange={(e) => setYtStrict(e.target.value)} className="w-full rounded-md border border-zinc-700 bg-zinc-900 px-2 py-1">
                <option>low</option><option>normal</option><option>high</option>
              </select>
            </label>
            <div className="flex items-center justify-end">
              <button onClick={runYT} disabled={ytLoading} className="rounded-lg bg-blue-600 px-3 py-1.5 text-sm text-white disabled:opacity-50">
                {ytLoading ? "Running…" : "Scrape"}
              </button>
            </div>
          </div>
          {ytRes && (
            <div className="mt-2 space-y-2">
              <div className="text-sm text-zinc-400">videos: {(ytRes?.results ?? []).length}</div>
              <div className="max-h-64 overflow-auto rounded-lg border border-zinc-800">
                <table className="min-w-full text-left text-sm">
                  <thead>
                    <tr className="text-zinc-400">
                      <th className="px-2 py-1">video</th>
                      <th className="px-2 py-1">kept_comments (sample)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(ytRes?.results ?? []).map((v, i) => (
                      <tr key={i} className="border-t border-zinc-800">
                        <td className="px-2 py-1">
                          <div className="font-medium">{v?.title}</div>
                          <div className="text-xs text-zinc-400">{v?.channel} · {v?.published}</div>
                        </td>
                        <td className="px-2 py-1">
                          <ul className="list-disc pl-4 text-xs">
                            {(v?.kept_comments ?? []).slice(0, 5).map((c, j) => (<li key={j} className="mb-1">{c}</li>))}
                          </ul>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </Card>

      <Card title="Reddit Scraper" right={<Badge>Sandbox</Badge>}>
        <div className="space-y-2">
          <input className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-2 py-1 text-sm" value={rdtSubs} onChange={(e) => setRdtSubs(e.target.value)} />
          <input className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-2 py-1 text-sm" value={rdtQuery} onChange={(e) => setRdtQuery(e.target.value)} />
          <div className="grid grid-cols-2 gap-2 text-sm">
            <label className="flex items-center gap-1">
              <span>limit</span>
              <input type="number" min={1} max={200} className="w-24 rounded-md border border-zinc-700 bg-zinc-900 px-2 py-1" value={rdtLimit} onChange={(e) => setRdtLimit(e.target.value)} />
            </label>
            <label className="flex items-center gap-1">
              <span>time</span>
              <select value={rdtTime} onChange={(e) => setRdtTime(e.target.value)} className="w-full rounded-md border border-zinc-700 bg-zinc-900 px-2 py-1">
                {['hour','day','week','month','year','all'].map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            </label>
            <label className="flex items-center gap-1">
              <span>strictness</span>
              <select value={rdtStrict} onChange={(e) => setRdtStrict(e.target.value)} className="w-full rounded-md border border-zinc-700 bg-zinc-900 px-2 py-1">
                <option>low</option><option>normal</option><option>high</option>
              </select>
            </label>
            <div className="flex items-center justify-end">
              <button onClick={runReddit} disabled={rdtLoading} className="rounded-lg bg-blue-600 px-3 py-1.5 text-sm text-white disabled:opacity-50">
                {rdtLoading ? "Running…" : "Scrape"}
              </button>
            </div>
          </div>
          {rdtRes && (
            <div className="mt-2 space-y-2">
              <div className="text-sm text-zinc-400">kept_count: {rdtRes?.kept_count ?? '—'}</div>
              <div className="max-h-64 overflow-auto rounded-lg border border-zinc-800">
                <table className="min-w-full text-left text-sm">
                  <thead>
                    <tr className="text-zinc-400">
                      <th className="px-2 py-1">kept_comments (sample)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(rdtRes?.kept_comments ?? []).slice(0, 25).map((c, i) => (
                      <tr key={i} className="border-t border-zinc-800"><td className="px-2 py-1 text-xs">{c}</td></tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Card title="Dropped by reason"><pre className="max-h-40 overflow-auto text-xs">{JSON.stringify(rdtRes?.dropped_by_reason ?? {}, null, 2)}</pre></Card>
            </div>
          )}
        </div>
      </Card>
      <ErrorToast error={err} onClose={() => setErr(null)} />
    </div>
  );
}

// ===================== ANALYZER =====================
function AnalyzerPanel() {
  const [text, setText] = useState("");
  const [res, setRes] = useState(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState(null);

  const run = async () => {
    setLoading(true); setErr(null);
    try {
      const reviews = text.split(/\n+/).map((s) => s.trim()).filter(Boolean);
      const data = await analyzeReviews(reviews);
      setRes(data);
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.response?.data?.error || e?.message || String(e);
      setErr(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
      <Card title="Input (one per line)" right={<Badge>Analyzer</Badge>}>
        <textarea
          rows={12}
          className="h-64 w-full rounded-xl border border-zinc-700 bg-zinc-900 p-3 text-sm outline-none focus:ring-2 focus:ring-blue-700"
          placeholder={`Love the ride quality but software feels buggy\nCharging network is a lifesaver\nPrice is too high for features`}
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <div className="mt-2 flex justify-end">
          <button onClick={run} disabled={loading} className="rounded-xl bg-blue-600 px-3 py-2 text-sm text-white disabled:opacity-50">
            {loading ? "Analyzing…" : "Analyze"}
          </button>
        </div>
      </Card>
      <Card title="Overview & Table">
        {!res && <div className="text-sm text-zinc-500">Run the analyzer to view results.</div>}
        {res && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <div className="text-zinc-400">Average sentiment</div>
                <div className="text-lg">{res?.overview?.average_sentiment?.toFixed?.(2) ?? "—"}</div>
              </div>
              <div>
                <div className="text-zinc-400">Top keyphrases</div>
                <div className="mt-1 flex flex-wrap gap-1">
                  {(res?.overview?.top_keyphrases ?? []).slice(0, 16).map((k, i) => (<Badge key={i}>{String(k)}</Badge>))}
                </div>
              </div>
            </div>
            <div className="max-h-72 overflow-auto rounded-lg border border-zinc-800">
              <table className="min-w-full text-left text-sm">
                <thead>
                  <tr className="text-zinc-400">
                    <th className="px-2 py-1">Sentiment</th>
                    <th className="px-2 py-1">Category</th>
                    <th className="px-2 py-1">Topics</th>
                    <th className="px-2 py-1">Keyphrases</th>
                    <th className="px-2 py-1">Text</th>
                  </tr>
                </thead>
                <tbody>
                  {(res?.per_review ?? []).map((r, i) => (
                    <tr key={i} className="border-t border-zinc-800">
                      <td className="px-2 py-1"><Badge tone={toneForSentiment(r?.sentiment)}>{r?.sentiment ?? "—"}</Badge></td>
                      <td className="px-2 py-1">{r?.review_category ?? "—"}</td>
                      <td className="px-2 py-1">
                        <div className="flex max-w-xs flex-wrap gap-1">{(r?.topic_labels ?? []).map((t, j) => (<Badge key={j}>{String(t)}</Badge>))}</div>
                      </td>
                      <td className="px-2 py-1">
                        <div className="flex max-w-xs flex-wrap gap-1">{(r?.keyphrases ?? []).slice(0, 6).map((k, j) => (<Badge key={j}>{String(k)}</Badge>))}</div>
                      </td>
                      <td className="px-2 py-1 max-w-lg truncate" title={r?.original}>{r?.original ?? ""}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </Card>
      <ErrorToast error={err} onClose={() => setErr(null)} />
    </div>
  );
}

// ===================== UNDERSTAND =====================
function UnderstandPanel() {
  const [res, setRes] = useState(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState(null);

  const onFile = async (f) => {
    setLoading(true); setErr(null);
    try {
      const data = await uploadCSV("/understand/upload", f);
      setRes(data);
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.response?.data?.error || e?.message || String(e);
      setErr(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
      <Card title="Upload CSV" right={<Badge>Understand</Badge>}>
        <input type="file" accept=".csv,text/csv" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-2 py-1 text-sm" />
        {loading && <div className="mt-2 text-sm text-zinc-400">Uploading…</div>}
      </Card>
      <Card title="Profile / Preview">
        {!res && <div className="text-sm text-zinc-500">Upload a CSV to see guessed columns & preview.</div>}
        {res && (
          <div className="space-y-3 text-sm">
            <div>
              <div className="text-zinc-400">Guessed columns</div>
              <div className="mt-1 flex flex-wrap gap-2">
                {Object.entries(res?.guessed_columns ?? {}).map(([k, v]) => (<Badge key={k} tone="blue">{k}: {String(v)}</Badge>))}
              </div>
            </div>
            <div>
              <div className="text-zinc-400">Columns</div>
              <div className="mt-1 flex flex-wrap gap-2">{(res?.columns ?? []).map((c, i) => (<Badge key={i}>{String(c)}</Badge>))}</div>
            </div>
            <div className="max-h-64 overflow-auto rounded-lg border border-zinc-800">
              <table className="min-w-full text-left text-sm">
                <thead>
                  <tr className="text-zinc-400">{(res?.columns ?? []).map((c, i) => (<th key={i} className="px-2 py-1">{String(c)}</th>))}</tr>
                </thead>
                <tbody>
                  {(res?.preview ?? []).map((row, i) => (
                    <tr key={i} className="border-t border-zinc-800">{(res?.columns ?? []).map((c, j) => (<td key={j} className="px-2 py-1 text-xs">{String(row?.[c] ?? "")}</td>))}</tr>
                  ))}
                </tbody>
              </table>
            </div>
            {res?.report_path && (
              <a className="inline-block rounded-lg bg-zinc-800 px-3 py-1 text-xs hover:bg-zinc-700" href={res.report_path} target="_blank" rel="noreferrer">
                Open Profile Report
              </a>
            )}
          </div>
        )}
      </Card>
      <ErrorToast error={err} onClose={() => setErr(null)} />
    </div>
  );
}

// ===================== FORECAST =====================
function ForecastPanel() {
  const [periods, setPeriods] = useState(30);
  const [res, setRes] = useState(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState(null);

  const onFile = async (f) => {
    setLoading(true); setErr(null);
    try {
      const data = await uploadCSV(`/forecast/predict?periods=${encodeURIComponent(periods)}`, f);
      setRes(data);
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.response?.data?.error || e?.message || String(e);
      setErr(msg);
    } finally {
      setLoading(false);
    }
  };

  const chartData = useMemo(() => res?.forecast ?? [], [res]);

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-5">
      <Card title="Upload CSV" right={<Badge>Forecast</Badge>}>
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-1 text-sm">
            <span>periods</span>
            <input type="number" min={1} max={365} value={periods} onChange={(e) => setPeriods(e.target.value)} className="w-24 rounded-md border border-zinc-700 bg-zinc-900 px-2 py-1" />
          </label>
          <input type="file" accept=".csv,text/csv" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-2 py-1 text-sm" />
        </div>
        {loading && <div className="mt-2 text-sm text-zinc-400">Uploading…</div>}
      </Card>
      <div className="md:col-span-4">
        <Card title="Forecast Chart">
          {chartData.length ? (
            <div className="h-64 w-full">
              <ResponsiveContainer>
                <AreaChart data={chartData} margin={{ left: 8, right: 8, top: 8, bottom: 8 }}>
                  <defs>
                    <linearGradient id="yhat" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopOpacity={0.5} />
                      <stop offset="95%" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="ds" minTickGap={24} />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="yhat_lower" name="Lower" fillOpacity={0.15} />
                  <Area type="monotone" dataKey="yhat_upper" name="Upper" fillOpacity={0.1} />
                  <Line type="monotone" dataKey="yhat" name="yhat" dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="text-sm text-zinc-500">Upload a CSV to render the forecast.</div>
          )}
        </Card>
        {res && (
          <Card title="Forecast Table">
            <div className="max-h-64 overflow-auto rounded-lg border border-zinc-800">
              <table className="min-w-full text-left text-sm">
                <thead>
                  <tr className="text-zinc-400">
                    <th className="px-2 py-1">ds</th>
                    <th className="px-2 py-1">yhat</th>
                    <th className="px-2 py-1">lower</th>
                    <th className="px-2 py-1">upper</th>
                  </tr>
                </thead>
                <tbody>
                  {chartData.map((r, i) => (
                    <tr key={i} className="border-t border-zinc-800">
                      <td className="px-2 py-1 text-xs">{String(r?.ds ?? "")}</td>
                      <td className="px-2 py-1 text-xs">{String(r?.yhat ?? "")}</td>
                      <td className="px-2 py-1 text-xs">{String(r?.yhat_lower ?? "")}</td>
                      <td className="px-2 py-1 text-xs">{String(r?.yhat_upper ?? "")}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </div>
      <ErrorToast error={err} onClose={() => setErr(null)} />
    </div>
  );
}

// ===================== APP SHELL =====================
export default function App() {
  const [tab, setTab] = useState("Insights");
  return (
    <div className="mx-auto max-w-7xl p-4 text-zinc-100">
      <header className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-semibold">InsightMesh AI</h1>
        <div className="text-xs text-zinc-400">MVP • React + Tailwind • /api/*</div>
      </header>
      <Tabs tabs={["Insights", "Scraper", "Analyzer", "Understand", "Forecast"]} value={tab} onChange={setTab} />
      {tab === "Insights" && <InsightsPanel />}
      {tab === "Scraper" && <ScraperPanel />}
      {tab === "Analyzer" && <AnalyzerPanel />}
      {tab === "Understand" && <UnderstandPanel />}
      {tab === "Forecast" && <ForecastPanel />}
      <footer className="mt-8 text-center text-xs text-zinc-500">
        Dual-input insights • Time-aware scrapers • Analyzer • Forecast — wired to your backend
      </footer>
    </div>
  );
}
